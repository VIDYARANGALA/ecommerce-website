//to demostrate jframe
import javax.swing.*;
import java.awt.*;
class jframe
{
    public static void main(String srg[])
    {
        JFrame f =new JFrame("frame title");
        f.setSize(500,300);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//to close the frame and to terminate the program
        FlowLayout fl=new FlowLayout();
        f.setLayout(fl);
        Container c=f.getContentPane();
        JButton b1=new JButton("click me");
        c.add(b1);
    }
}