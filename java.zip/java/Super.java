//accesing super class members(variables&methods)using super keyword
class A
{
    int p=10;
    void show()
    {
        System.out.println("class A p value is: "+p);
    }
    
}
class B extends A
{
    int p=20;
    int q=30;
    void show()
    {
        super.show();//accesing instance class method using super
        System.out.println("class B p value is: "+super.p);//accesing instance class variable using super keyword
        System.out.println("class B p value is: "+p);
        System.out.println("class B q value is: "+q);
    }
}
class Super
{
    public static void main(String a[])
    {
        B obj=new B();
        obj.show();
    }
}