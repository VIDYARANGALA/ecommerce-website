import accessmodifier.sameclass;
import accessmodifier.spsc;
import accessmodifier.spnc;
import otheraccessmodifier.opsc;
import otheraccessmodifier.opnc;
class Accessmainclass
{
    public static void main(String x[])
    {
        //sameclass obj=new sameclass();
       
        //spsc obj2=new spsc();
        //spnc obj3=new spnc();
        //opsc obj4=new opsc();
        opnc obj5=new opnc();
        
    }

}