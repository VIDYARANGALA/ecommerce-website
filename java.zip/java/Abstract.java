//program for abstract classes
abstract class CGovt
{
    void otherdirections()
    {
        System.out.println("it is method otherdirections");

    }
    abstract void actionsTobeTaken();
}
class AP extends CGovt
{
    void actionsTobeTaken()
    {
        System.out.println("it is method actionstobetaken in AP");
    }
}
class TG extends CGovt
{
    void actionsTobeTaken()
    {
        System.out.println("it is method actionstobetaken in TG");
    }

}
class Abstract
{
    public static void main(String a[])
    {
        AP ap=new AP();
        ap.otherdirections();
        ap.actionsTobeTaken();
        TG tg=new TG();
        tg.otherdirections();
        tg.actionsTobeTaken();
    }
}