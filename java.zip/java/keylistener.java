 //to deonstrate keylistener
 import java.awt.*;
 import java.awt.event.*;
 class keylistener extends Frame implements KeyListener
 {
    TextArea ta1;
    String msg;
    keylistener()
    {   
        FlowLayout fl=new FlowLayout();
        this.setLayout(fl);
        ta1=new TextArea("",10,25);
        
        this.add(ta1);
        ta1.addKeyListener(this);
    }
    public void keyPressed(KeyEvent e)
    {
         int code=e.getKeyCode();
         String kname=e.getKeyText(code);
         msg=code+"-"+kname;
         repaint();
    }
    public void keyReleased(KeyEvent e)
    {

    }
    public void keyTyped(KeyEvent e)
    {

    }
    public void paint(Graphics g)
    {
        g.drawString(msg,40,700);
    }

    public static void main(String arg[])
    {
        keylistener f=new keylistener();
        f.setSize(400,300);
        f.setVisible(true);
    }
 }
