//accessing variables and methods in a subclass from other package
package otheraccessmodifier;
import accessmodifier.sameclass;
public class opsc extends sameclass

{
    public opsc()
    {
        
        
        System.out.println("a value frow opsc"+a);
        //System.out.println("b value frow sameclass"+b);
        System.out.println("c value frow opsc"+c);
        //System.out.println("d value frow sameclass"+d);
        

        
    }

}