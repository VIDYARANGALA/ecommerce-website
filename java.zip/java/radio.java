//to demonstrateradio buttons in awt
import java.awt.*;
import java.awt.event.*;
class radio extends Frame implements ItemListener
{
    Checkbox c1,c2,c3;
    radio()
    {
        FlowLayout fl=new FlowLayout();
        this.setLayout(fl);

        CheckboxGroup cg=new CheckboxGroup();

        c1= new Checkbox("male",false,cg);
        this.add(c1);
        c1.addItemListener(this);
        c2 =new Checkbox("female",false,cg);
        this.add(c2);
        c2.addItemListener(this);
        c3=new Checkbox("others",false,cg);
        this.add(c3);
        c3.addItemListener(this);

    }

public void paint(Graphics g)

{
    g.drawString("you have selected male"+c1.getState(),10,100);
    g.drawString("you have selected female"+c2.getState(),10,150);
    g.drawString("you have selected others"+c3.getState(),10,200);

}
public void itemStateChanged(ItemEvent e)
{
    repaint();
}


    public static void main(String arg[])
    {
        radio r=new radio();
        r.setSize(400,200);
        r.setVisible(true);

    }

}