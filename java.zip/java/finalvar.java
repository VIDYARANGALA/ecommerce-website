//using final keyword for variables
class finalvar
{
    public static void main(String p[])
    {
       final int a=23;
      
        //System.out.println("value of a is"+a);
        a=34;//34 cant replace 23 because we declared it as final
        System.out.println("value of a is"+a);
        
    }
}