import java.io.*;
class add

{
	public static void main(String x[])throws Exception
	{	
		//InputStreamReader reads input from keyboard
		InputStreamReader i= new InputStreamReader(System.in/*keyboard*/);
		//BufferdReader reads input from InputStreamReader
		BufferedReader b=new BufferedReader(i/*InputStreamReader*/);
		System.out.println("enter firstnumber");
		int a=Integer.parseInt(b.readLine());
		System.out.println("enter second number");
		int c=Integer.parseInt(b.readLine());//Integer.parseInt is used to convert any datatype into integer
		int d=a+c;
		System.out.println("addition is:"+d);
		
	}
}
		
