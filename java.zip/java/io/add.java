import java.util.*;
class add
{
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter firstnumber");
		int firstnumber=s.nextInt();
		System.out.println("enter secondnumber");
		int secondnumber=s.nextInt();
		int result=firstnumber+secondnumber;
		System.out.println("result is:"+result);
	}
}
