//reading multi character use readLine()
import java.io.*;
class IOmulti
{
	public static void main(String x[])throws Exception
	{	
		//InputStreamReader reads input from keyboard
		InputStreamReader i= new InputStreamReader(System.in/*keyboard*/);
		//BufferdReader reads input from InputStreamReader
		BufferedReader b=new BufferedReader(i/*InputStreamReader*/);
		System.out.println("what's your name");
		String s=b.readLine();
		System.out.println("Heyy!!! "+s+" You are beautiful in and out :)");
		
		
	}
}
		
