//reading single character use read()
import java.io.*;
class IO
{
	public static void main(String x[])throws Exception
	{	
		//InputStreamReader reads input from keyboard
		InputStreamReader i= new InputStreamReader(System.in/*keyboard*/);
		//BufferdReader reads input from InputStreamReader
		BufferedReader b=new BufferedReader(i/*InputStreamReader*/);
		System.out.println("enter a character");
		
		System.out.println("you entered :"+b.read());//returns ascii value of entered character
		
		System.out.println("you entered :"+(char)b.read());//returns the character u entered
	}
}
		
