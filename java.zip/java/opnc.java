//other package non sub class 
package otheraccessmodifier;
import accessmodifier.sameclass;
public class opnc
{
    public opnc()
    {
        sameclass obj=new sameclass();
        System.out.println("a value frow opnc"+obj.a);
        //System.out.println("b value frow opnc"+obj.b);
        //System.out.println("c value frow opnc"+obj.c);
        //System.out.println("d value frow opnc"+obj.d);
        
    }
}