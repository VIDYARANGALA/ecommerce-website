class Switch
{
	public static void main(String args[])
	{
		int a=6;
		int b=2;
		int c=a+b;
		switch(c)
		{
			case 3:System.out.println("addition is 3");
			break;
			case 7:System.out.println("addition is 7");
			break;
			default:System.out.println("addition is "+c);
		}
	}
}
