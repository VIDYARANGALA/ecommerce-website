class ElseIfElse
{
	public static void main(String x[])
	{
		int a=7;
		if(a==5)
		{
			System.out.println("a value is 5");
		}
		else if(a==3)
		{
			System.out.println("a value is 3");
		}
		else
		{
			System.out.println("a value is "+a);
		}
	}
}
