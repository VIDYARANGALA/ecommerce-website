class If
{
	public static void main(String x[])
	{
		int a=5;
		if(a==5)
		{
			System.out.println("a value is "+a);
		}
	}
}
