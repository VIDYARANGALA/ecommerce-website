class IfElse
{
	public static void main(String x[])
	{
		int a=5;
		if(a==10)
		{
			System.out.println("a value is "+a);
		}
		else
		{
			System.out.println("a value is"+a);
		}
	}
}
