class For
{
	public static void main(String args[])
	{
		for(long i=0;i<100000;i++)
		{
			System.out.println("hello");
		}
	}
}
