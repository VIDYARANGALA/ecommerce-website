class DoWhile
{
	public static void main(String y[])
	{
		int i=0;
		do
		{
			System.out.println("MSD");
			i++;
		}while(i<7);
	}
}
	
