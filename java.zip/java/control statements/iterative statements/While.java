class While
{
	public static void main(String args[])
	{
		int i=7;
		while(i>0)
		{
			System.out.println("V_The Queen");
			i--;

		}
	}
}
		
