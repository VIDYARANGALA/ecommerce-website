//call by reference
class Sample
{
    void check(Ex obj)
    {
        obj.v1=2;
        obj.v2=3;
    }

}
class Ex
{
    int v1;
    int v2;
}
class Referance
{
    public static void main(String c[])
    {
        Sample s=new Sample();
        Ex obj1=new Ex();
        obj1.v1=76;
        obj1.v2=78;
        System.out.println("v1,v2 values are: "+obj1.v1+','+obj1.v2);
        s.check(obj1);
        System.out.println("v1,v2 values are: "+obj1.v1+','+obj1.v2);

    }
}
