//program for calling methods without parameters
class Ex
{
    int a;
    int b;

    void add()
    {
        System.out.println("addition is: "+(a+b));

    }
    void mul()
    {
        System.out.println("multiplication is: "+(a*b));
    }
}
class Methods2
{
    public static void main(String a[])
    {
        Ex obj1=new Ex();
        obj1.a=32;
        obj1.b=45;
        obj1.add();
        obj1.mul();
    }
}