//program to pass parameters for methods using arrays
class arrays
{
    void array(int a[])
    {
        for(int i=0;i<a.length;i++)
        System.out.println(a[i]);
    }
}
class Methods5
{
    public static void main(String c[])
    {
        arrays obj=new arrays();
        int p[]={1,2,3,4,5};
        obj.array(p);
    }
}












    

