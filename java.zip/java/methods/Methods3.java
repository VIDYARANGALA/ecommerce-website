//call by value
class Ex
{
    void add(int a,int b)
    {
        int c=a+b;
        System.out.println("a,b values are: "+a+','+b);
        System.out.println("addition is: "+c);
        

        a=32;
        b=23;
        c=a+b;
        System.out.println("a,b values are: "+a+','+b);
        System.out.println("addition 2 is:"+c);
    }
}
class Methods3
{
    public static void main(String a[])
    {
        Ex obj=new Ex();
        int p=16;
        int q=17;
        System.out.println("p,q values are: "+p+','+q);
        obj.add(p,q);
        System.out.println("p,q values are: "+p+','+q);
        
    }
}