//call by reference
class Sample
{
    int v1;
    int v2;
    void check(Sample obj1)
    {
        obj1.v1=2;
        obj1.v2=3;
    }

}

class Referance1
{
    public static void main(String c[])
    {
        Sample obj1=new Sample();
         obj1.v1=8;
        obj1.v2=78;
        System.out.println("v1,v2 values are: "+obj1.v1+','+obj1.v2);
        obj1.check(obj1);
        System.out.println("v1,v2 values are: "+obj1.v1+','+obj1.v2);

    }
}
