//program for calling methods with parameters
class Ex
{
    int a;
    int b;

    void add(int a,float b)
    {
        System.out.println("addition is: "+(a+b));

    }
    void mul(float a,float b)
    {
        System.out.println("multiplication is: "+(a*b));
    }
}
class Methods
{
    public static void main(String a[])
    {
        Ex obj1=new Ex();
        
        obj1.add(3,4.2f);
        obj1.mul(2.7f,2.8f);
    }
}