//static variables & static methods
class vidya
{
    String name;//instance variable
    void dance()//instance method
    {
        System.out.println(name+" is dancing on floor");
    }
    static String nam;//static variable
    static void browse()//static method
    {
        System.out.println(nam+" is browsing internet");
    }
}
class Static
{
    public static void main(String a[])
    {
        vidya rangala=new vidya();//calling instance variables and method
        rangala.name="VidyaRangala";
        rangala.dance();

        vidya.nam="VidyaRangala";//calling static variable and method
        vidya.browse();

    }
    static//static block
    {
        System.out.println("static block executes firstly among all classes");
    }
}
