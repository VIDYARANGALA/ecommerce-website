//to demonstrate flowlayout and button
import java.awt.*;
class cardlayout extends Frame
{
    public static void main(String[] args) 
    {
        cardlayout f=new cardlayout();
        f.setSize(100,200);
        f.setVisible(true);
        CardLayout fl=new CardLayout(10,20);
        f.setLayout(fl);
        Button b=new Button("enter");
        f.add("enter",b);
        Button b1=new Button("exit");
        f.add("exit",b1);
        Button b2=new Button("login");
        f.add("login",b2);
        Button b3=new Button("enter1");
        f.add("enter1",b3);
        Button b4=new Button("enter2");
        f.add("enter2",b4);
        Button b5=new Button("enter3");
        f.add("enter3",b5);
        f.setBackground(Color.gray);
        //fl.last(f);//displays last cord
        fl.next(f);//displays next card i.e,exit
        fl.next(f);//displays next card to exit i.e,login
        fl.previous(f);
        fl.show(f,"enter3");

        
    }
}