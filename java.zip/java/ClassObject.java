class human
{
    //instance variables
    String name;
    int age;
    //instance methods
    void talk()
    {
        System.out.println(name+ " is talking");

    }
    void walk()
    {
        System.out.println(name+" is walking");
    }
   
}
class ClassObject
{
    public static void main(String x[])
    {
        human vidya=new human();
        vidya.name="vidyarangala";
        vidya.age=20;
        vidya.walk();
        vidya.talk();

        human arjun=new human();
        arjun.name="Allu Arjun";
        arjun.age=20;
        arjun.walk();
        arjun.talk();
    }
}