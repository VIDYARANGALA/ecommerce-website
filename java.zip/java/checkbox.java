//program to demonstrate checkboxs in awt
import java.awt.*;
import java.awt.event.*;
class checkbox extends Frame implements ItemListener
{
    Checkbox c1,c2,c3;
    checkbox()
    {
        FlowLayout fl=new FlowLayout();
        this.setLayout(fl);

        c1=new Checkbox("telugu");
        this.add(c1);
        c1.addItemListener(this);

        c2=new Checkbox("hindi");
        this.add(c2);
        c2.addItemListener(this);

        c3=new Checkbox("english");
        this.add(c3);
        c3.addItemListener(this);



    }
    public void paint(Graphics g)
    {
       
        g.drawString("you have selected telugu"+c1.getState(),10,100);
        g.drawString("you have selected hindi"+c2.getState(),10,150);
        g.drawString("you have selected english"+c3.getState(),10,200);

    }
    public void itemStateChanged(ItemEvent e)
    {

        repaint();
    }
    public static void main(String arg[])
    {
        checkbox c=new checkbox();
        c.setSize(400,300);
        c.setVisible(true);
    }
}