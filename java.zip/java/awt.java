//to demonstrate awt
import java.awt.*;
class awt
{
    public static void main(String args[])
    {
        Frame f=new Frame("frame title");//creating a frame
        f.setSize(200,300);//setting frame size
        f.setVisible(true);//making frame visible(bydefault it is false)

    }
}
