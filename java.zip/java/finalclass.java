//creating a class using final keyword it doesn't support inheritance
final class A 
{
    int a=10;
    int b=23;
    void add()
    {
        System.out.println("addition is "+(a+b));
    }
}
class B extends A//error
{
    int d=23;
    int s=34;
    void add()
    {
        System.out.println("addition is "+(a+b));
        System.out.println(d+s);
    }
}


class finalclass
{
    public static void main(String ar[])
    {
       B obj=new B();
       obj.add();
    }
}