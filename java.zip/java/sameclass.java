//accessing methods and variables in same class
package accessmodifier;

public class sameclass
{
    public int a=10;
    private int b=20;
    protected int c=30;
    int d=40;
    public sameclass()
    {
        System.out.println("a value frow sameclass"+a);
        System.out.println("b value frow sameclass"+b);
        System.out.println("c value frow sameclass"+c);
        System.out.println("d value frow sameclass"+d);
        

    }
        
    
}