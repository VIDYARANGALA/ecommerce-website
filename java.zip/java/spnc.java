//accessing methods and variables from samepackage non subclass
package accessmodifier;
public class spnc
{
    public spnc()
    {    
        sameclass obj=new sameclass();
         
        System.out.println("a value frow spnc"+obj.a);
        //System.out.println("b value frow spnc"+obj.b);
        System.out.println("c value frow spnc"+obj.c);
        System.out.println("d value frow spnc"+obj.d);
        
    }
   
}