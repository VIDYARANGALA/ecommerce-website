class Myexception extends Exception
{
    /*Myexception(){
        System.out.println("cmp is for 10 below");

    }*/
    Myexception(String str)
    {
        //super(str);
    }
}
class Userexception
{
    public static void main(String args[])
    {
        int age=11;
        try{
            if(age>10)
                throw new Myexception("pls enter age below 10");
        }
        catch(Myexception e)
        {
            System.out.println("only below 10");
        }
        System.out.println("hello");
    }
}