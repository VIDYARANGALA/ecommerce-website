package Package;
public class Second
{
    public int a=23;
    public int b=45;
    public void sub()
    {
        System.out.println("sub of variables in class second "+(a-b));
    }
}