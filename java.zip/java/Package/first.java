package Package;
public class first
{
    public int x=10;
    public int y=20;
    public void add()
    {
        System.out.println("addition of class variables is "+(x+y));
    }
}