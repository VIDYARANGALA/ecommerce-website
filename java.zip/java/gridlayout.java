//to demonstrate flowlayout and button
import java.awt.*;
class gridlayout extends Frame
{
    public static void main(String[] args) 
    {
        gridlayout f=new gridlayout();
        f.setSize(100,200);
        f.setVisible(true);
        GridLayout fl=new GridLayout(6,1,20,20);
        f.setLayout(fl);
        Button b=new Button("enter");
        f.add(b);
        Button b1=new Button("exit");
        f.add(b1);
        Button b2=new Button("login");
        f.add(b2);
        Button b3=new Button("enter1");
        f.add(b3);
        Button b4=new Button("enter2");
        f.add(b4);
        Button b5=new Button("enter3");
        f.add(b5);
        f.setBackground(Color.gray);

        
    }
}