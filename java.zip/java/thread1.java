

//to demostrate threads
class MyThread extends Thread
{
    String tname;
    MyThread(String s)
    {
        tname=s;
    }
    public void run()
    {
        for(int i=1;i<=10;i++)
        {
            System.out.println(tname+":"+i);
            try{
                Thread.sleep(200);

            }
            catch(Exception e){}
        }
        
    }
}
class thread1
{
    public static void main(String ard[])
    {
        Thread t=Thread.currentThread();
        System.out.println(t);//prints the info about main thread        
        ThreadGroup td=new ThreadGroup("tg");



        //first child thread
        MyThread t1=new MyThread("first");//creating object for above created clss
        Thread th=new Thread(td,t1);//thread object linking to our class object
        t1.setName("first");//setting name for the thread
        t1.setPriority(7); //setting priority for the thrad 
        try{  
             t1.join();//join() helps to complete its excetion first while every other thread waits
        }
        catch(Exception e){}
        t1.setDaemon(true);
        System.out.println(t1);  
        th.start();//run the thread using start()

        //second thread child
        MyThread t2=new MyThread("second");
        t2.setName("second");
        t2.setPriority(1);
        Thread th2=new Thread(td,t2);
        th2.setPriority(10);
        System.out.println(t2);
        th2.start();
        try{
            t.sleep(2000);//to temporarily stop a statements for certain time
            //t.join();
        }
        catch(Exception e){}
        System.out.println("is thread a deamon "+t.isDaemon());
        System.out.println("is first thread daemon "+ t1.isDaemon());
        System.out.println("is 2nd thread daemon " +t2.isDaemon());
        System.out.println("main ends");

    }
}