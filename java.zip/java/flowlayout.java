//to demonstrate flowlayout and button
import java.awt.*;
class flowlayout extends Frame
{
    public static void main(String[] args) 
    {
        flowlayout f=new flowlayout();
        f.setSize(100,200);
        f.setVisible(true);
        FlowLayout fl=new FlowLayout(FlowLayout.LEFT,10,20);
        f.setLayout(fl);
        Button b=new Button("enter");
        f.add(b);
        Button b1=new Button("exit");
        f.add(b1);
        Button b2=new Button("login");
        f.add(b2);
        f.setBackground(Color.gray);

        
    }
}