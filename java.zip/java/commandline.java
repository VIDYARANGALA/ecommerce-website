//we pass inputs along with execution command line
class commandline
{
    public static void main(String ar[])
    {
        int a=Integer.parseInt(ar[0]);
        int b=Integer.parseInt(ar[1]);
        System.out.println("addition of inputs user entered is: "+(a+b));
    }
}