//exception handling using try,catch,finally
class exception 
{
    public static void main(String ad[])
    {
        try
        {
            System.out.println(2+3);
            System.out.println(5-3);
            System.out.println(2*67);
            System.out.println(5/0);//produces expection
            System.out.println("hello VR");
        }
        catch(ArithmeticException e)
        {
            System.out.println("do not divide any number by zero");
        }
        finally
        {
            System.out.println("hello VR");
        }
    }
}