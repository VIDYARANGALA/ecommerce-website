class SBMethods
{
    public static void main(String a[])
    {
        StringBuffer str=new StringBuffer();
        StringBuffer str1=new StringBuffer("vivo ipl 2023 starts on march 31st,with CSK vs GT");
        str.append("hello ");
        str.append(7+" " );
        str.append(7.7+" ");
        System.out.println("using append()\n"+str);//append()
        str.insert(1,"vidya");//insert inserts value at index 1
        System.out.println("using insert(): "+str);
        str.delete(2,9);//delete(stasting index,endingindex)
        System.out.println("using delete(): "+str);
        str.reverse();//reverse
        System.out.println("using reverse: "+str);
        str1.length();//lenth()
        System.out.println("using length(): "+str1.length());
        System.out.println("using rostring; "+str.toString());//toString
        System.out.println("using indexof: "+str1.indexOf("v"));//indexof 
        System.out.println("using lastindexof: "+str1.lastIndexOf("s"));//lastindexof
        System.out.println("using replace: "+str1.replace(2,4,"MSD"));//replace
        System.out.println("using substring: "+str1.substring(3,8));//substring
    }    
}