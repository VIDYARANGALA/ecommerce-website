class StringMethods
{
	public static void main(String x[])
	{
		String s1="Welcome to ";
		String s2=s1.concat("Java Programing");//String concat(string)
		System.out.println("concatenation :" +s2);
		char c=s2.charAt(3);// char charAt(int)
		System.out.println("character at given index is: "+c);
		System.out.println("length of string is:"+s2.length());//length()
		String s3="   you are learning java	";
		String s4="You are learning java";
		System.out.println("after comparing two strings with considering case,result is:"+s3.compareTo(s4));//compareTo()
		System.out.println("after comparing 2 strings without considering case,result is:"+s3.compareToIgnoreCase(s4));//compareToIgnoreCase()
		System.out.println("after equaling two strings with considering case,result is:"+s3.equals(s4));//equals()
		System.out.println("after equaling 2 strings without considering case,result is:"+s3.equalsIgnoreCase(s4));//equalsIgnoreCase()
		System.out.println("using startsWith():"+s3.startsWith("you"));//startsWith()
		System.out.println("using endsWith():"+s3.endsWith("you"));//endsWith()                                                     
		System.out.println("using index():"+s3.indexOf("a"));//indexOf() returns the index value that occured first
		System.out.println("using lastIndexOf():"+s3.lastIndexOf("a"));//lastIndexOf() returns the index value that occured last
		System.out.println("using replace():"+s2.replace(' ','@'));//replace() replaces given first char with second char
		System.out.println("using substring with single index:"+s3.substring(3));//substring()
		System.out.println("using substring with double index:"+s3.substring(3,8));//substring() with double index
		System.out.println("using toLowerCase():"+s2.toLowerCase());//toLowerCase coverts entire string into lowercase	
		System.out.println("using toUpperCase():"+s2.toUpperCase());//toUpperCase coverts entire string into uppercase	
		System.out.println("using trim():"+s3.trim());//trim() removes spaces which are at starting and ending of strings not in b/w string
		String res[]=s2.split("o");
		System.out.println("no.of substrings that are splits:"+res.length);//splits string into smaller sustring at specified location
		for(int i=0;i<res.length;i++)
		
			System.out.println(res[i]);
		
		char a[]=new char[100];//getchars()
		s1.getChars(2,9,a,0);
		System.out.println(a);
	}
}

