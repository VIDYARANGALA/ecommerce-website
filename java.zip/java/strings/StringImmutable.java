class StringImmutable
{
    public static void main(String args[])
    {
        String str=new String("hello");
        System.out.println("initially string is "+str);
        System.out.println("hashcode is "+str.hashCode());
        str="hi";
        System.out.println("after updating string is "+str);
        System.out.println("hashcode is "+str.hashCode());
    }
}