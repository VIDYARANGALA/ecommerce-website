//to read a file using bytestream
import java.io.*;
class filereadbyte
{
    public static void main(String ar[])throws Exception
    {
        //open a file
        FileInputStream fis=new FileInputStream("head.txt");

        //reading a file
        int ch;
        while((ch=fis.read())!=-1)
        {
            System.out.print((char)ch);
        }
    }
}