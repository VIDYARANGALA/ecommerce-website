//to write content into file
import java.io.*;
class filewrite
{
    public static void main(String args[])throws Exception
    {   //using filewriter
        FileWriter fw=new FileWriter("sample.txt",true);
       

        //using bufferedwriter
        BufferedWriter bw=new BufferedWriter(fw);
        char c[]={'w','e','l','c','o','m','e'};
        bw.write(c, 0,5);

        //String s="java programming";
        //bw.write(s, 0,s.length());
        //String p=" hello world";
        //bw.write(p, 0,p.length());
        String s="java programming";
        bw.write(s, 0,s.length());
        bw.close();
        fw.close();


    }
}