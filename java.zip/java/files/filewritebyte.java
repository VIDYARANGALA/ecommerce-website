//writingcontent into a file using byte streams
import java.io.*;
class filewritebyte
{
    public static void main(String ar[])throws Exception
    {
        FileOutputStream fos=new FileOutputStream("filebyte.txt");
        fos.write((int)'x');
       
        byte b[]={22,34,67,45,67};
        fos.write(b);


        fos.close();


    }
}