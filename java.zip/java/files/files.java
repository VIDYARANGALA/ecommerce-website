//todemonstrate files and its methods
import java.io.*;
class files
{
    public static void main(String arg[])throws Exception
    {
        File f=new File("vidya.txt");
        System.out.println("exists()"+f.exists());//method exists()
        if(f.exists()==true)
        {
            System.out.println("canRead()"+f.canRead());//method to check whether can be read
            System.out.println("canWrite()"+f.canWrite());//method to check whether can be written
            f.delete();//method
            System.out.println("exists()"+f.exists());
            
        }
        File e=new File("rNl.txt");
            System.out.println("file created"+e.createNewFile());//method to create a file
    }
}