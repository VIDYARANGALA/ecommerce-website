//to copy paste an image
import java.io.*;
class filecopy
{
    public static void main(String ar[])throws Exception
    {
        FileInputStream fis=new FileInputStream("ironman.jpg");

        
        FileOutputStream fos=new FileOutputStream("ironman1.jpg");
        int ch;
        while((ch=fis.read())!=-1)
        fos.write(ch);
        fos.close();
        fis.close();
    }
}