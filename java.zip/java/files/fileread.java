//to read content from a file
import java.io.*;
class fileread
{
    public static void main(String arg[])throws Exception
    {   //using filereader
        FileReader fr=new FileReader("head.txt");
        /*int ch;
        while((ch=fr.read())!=-1)
        {
            System.out.print((char)ch);
        }*/

        //using bufferedreader

        BufferedReader br=new BufferedReader(fr);
        String s;
        while((s=br.readLine())!=null)
        {
            System.out.println(s);
        }
    }
}