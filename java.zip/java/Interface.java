interface A
{
    int a=10;
    void show();
    void display();
}
class B implements A
{
    public void show()
    {
        System.out.println("it a show method in B");
    }
    public void display()
    {
        System.out.println("It is display method in B");
    }
}
class Interface
{
    public static void main(String a[])
    
    {
        B obj=new B();
        obj.show();
        obj.display();    
    }
}