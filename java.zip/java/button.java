//program to demonstrate a button in awt
import java.awt.*;
import java.awt.event.*;
class button extends Frame implements ActionListener
{
   
    button()
    {   
         FlowLayout f1=new FlowLayout();
         this.setLayout(f1);
        //step1: create a component
        Button b=new Button("cyan");

        //step2: add component to the container
        this.add(b);

        //step3: add listener to the compoment
        b.addActionListener(this);

        Button b2=new Button("blue");
        this.add(b2);
        b2.addActionListener(this);

        Button b3=new Button("yellow");
        this.add(b3);
        b3.addActionListener(this);


    }
    //step3.1: implement methods of the listener
    public void actionPerformed(ActionEvent e)
    {
        String bname=e.getActionCommand();
        if(bname.equals("cyan"))
        {
            this.setBackground(Color.CYAN);
        }
        if(bname.equals("blue"))
        {
            this.setBackground(Color.BLUE);
        }
        if(bname.equals("yellow"))
        {
            this.setBackground(Color.YELLOW);
        }
        
    }

    public static void main(String arg[])
    {
        button f=new button();
        f.setSize(400,300);
        f.setVisible(true);
    }
}