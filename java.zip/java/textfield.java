//to demonstrate textfield,label,teaxt area,choice,list
import java.awt.*;
import java.awt.event.*;
class textfield extends Frame
{   
    Label l1,l2,l3,l4,l5;
    TextField tf1,tf2;
    TextArea ta1;
    Choice ch1;
    List li1;
    textfield()
    {   
        
        this.setLayout(null);
        l1=new Label("name");
        l1.setBounds(30,30,80,20);
        this.add(l1);
        tf1=new TextField("enter your name ");
        tf1.setBounds(150,30,80,20);
        this.add(tf1);
        l2=new Label("password");
        l2.setBounds(30,80,80,20);
        this.add(l2);
        tf2=new TextField("enter password");
        tf2.setBounds(120,80,80,20);
        this.add(tf2);

        l3=new Label("address");
        l3.setBounds(30,120,80,20);
        this.add(l3);

        ta1=new TextArea("",50,50,TextArea.SCROLLBARS_BOTH);
        ta1.setBounds(150,120,80,80);
        this.add(ta1);

        l4=new Label("country");
        l4.setBounds(30,200,80,20);
        this.add(l4);

        ch1=new Choice();
        ch1.add("India");
        ch1.add("US");
        ch1.add("UK");
        ch1.add("Pakistan");
        ch1.setBounds(150,150,80,80);
        this.add(ch1);

        l5=new Label("interest");
        l5.setBounds(30,290,80,20);
        this.add(l5);

        li1=new List(3,true);
        li1.add("reading books");
        li1.add("listening to music");
        li1.add("dancing");
        li1.add("singing");
        li1.add("clicking");
        li1.add("playing");
        li1.setBounds(150,290,80,100);
        this.add(li1);




    }

    public static void main(String arg[])
    {
        textfield t=new textfield();
        t.setSize(400,300);
        t.setVisible(true);
    }
}