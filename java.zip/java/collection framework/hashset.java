//hashset methods
import java.util.*;
class hashset
{
    public static void main(String arg[])
    {
        HashSet<String>names=new HashSet<String>();
        System.out.println("isEmpty()method: "+names.isEmpty());//isEmpty()
        names.add("vidya");//add()
        names.add("rangala");
        System.out.println("isEmpty()method: "+names.isEmpty());
        if(names.contains("vida"))//contains()
        {
            System.out.println(names.remove("vidy"));//remove()
        }
        else{
            System.out.println(names.size());//size()
        }

        names.clear();//clear()
        System.out.println("isEmpty()method: "+names.isEmpty());


        names.add("apple");
        names.add("bat");
        names.add("cat");
        names.add("dog");
        names.add("egg");
        System.out.println(names);

        //accessing values using for-each loop
        /*for(String v:names)
        {
            String newvalue="it is "+v;
            System.out.println(newvalue);
        }*/

        //using iterator for accesing values

        Iterator<String> newnames=names.iterator();
        while(newnames.hasNext())
        {
            String n=newnames.next();
            System.out.println("it is: "+n);
        }

    }
}
