//to demostrate stack and its methods
import java.util.*;
class stack
{
    public static void main(String ard[])
    {
        Stack<Integer> i=new Stack<Integer>();

        i.push(97);//method push()
        i.push(45);
        i.push(90);
        i.push(43);
        i.push(45);
        i.push(94);

        System.out.println(i.peek());//method peek()
        System.out.println(i.pop());//method pop()
        System.out.println(i.search(90));//method search()
        System.out.println(i.pop());//method pop()
        System.out.println(i);
        System.out.println(i.peek());



    }
}