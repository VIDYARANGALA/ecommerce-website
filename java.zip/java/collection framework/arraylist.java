//to demostrate arraylist and its methods
import java.util.*;
class arraylist
{
    
    public static void main(String arg[])
        {
            ArrayList<String> list=new ArrayList<String>();
            list.add("vidya");//to add data into linked list add()
            list.add("rangala");
            list.add("apple");
            list.add(1,"mango");  
            //no addlast,addlast,getfirst,getlast,are not their in arraylist like linkedlist
            System.out.println(list);
            System.out.println("is list contains vidya? "+list.contains("vidya"));//to check whether a value is present or not contains()
           
            System.out.println(list.get(3));//to get value at specfic index get()
            System.out.println(list.size());//to get no.of elements in the list size()
            System.out.println("removed first element"+list.remove("rangala"));//removes given element of list
            System.out.println(list.remove(2));
            System.out.println(list.size());
            System.out.println("is array list empty? "+list.isEmpty());
            System.out.println(list);
            ListIterator<String> l=list.listIterator();//converting arraylist into iterator
            while(l.hasNext())
            {
                String s=l.next();
                System.out.println(s);
            }
            /*for(String s:list)//to read & print each value of the list
            {
                System.out.println(s);
            }*/
        }
    
}