//to demostrate linkedlist and its methods
import java.util.*;
class linkedlist
{
    
    public static void main(String arg[])
        {
            LinkedList<String> list=new LinkedList<String>();
            list.add("vidya");//to add data into linked list add()
            list.add("rangala");
            list.add("apple");
            list.add(1,"mango");  
            list.addFirst("hello");//to add data at starting of the linkedlist addFirst()
            list.addLast("sayonara!!!");//to add data at ending of the linkedlist addFirst()
            System.out.println(list);
            System.out.println("is list contains vidya? "+list.contains("vidya"));//to check whether a value is present or not contains()
            System.out.println("first element in the list is "+list.getFirst());//to get first element of linked list getFirst()
            System.out.println("last element of list is "+list.getLast());//to get last element of the linkedlist getLast() 
            System.out.println(list.get(3));//to get value at specfic index get()
            System.out.println(list.size());//to get no.of elements in the list size()
            System.out.println("removed first element"+list.remove());//removes first element of list
            System.out.println("removed element at specific index"+list.remove(2));//to remove at specific index
            System.out.println("removed last element"+list.removeLast());//to remove last index
            System.out.println(list.size());
            System.out.println(list);
            for(String s:list)//to read & print each value of the list
            {
                System.out.println(s);
            }
        }
    
}