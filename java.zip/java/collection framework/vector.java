//program to demostrate vector and its methods
import java.util.*;
class vector
{
    public static void main(String arg[])
    {
        Vector<String> v=new Vector<String>(6,3);//(intial capacity(6),capacity increament(3))
        System.out.println("intial capacity"+v.capacity());//to check capacity of vector capacity()
        v.add("a");
        v.add("b");
        v.add("c");
        v.add("d");
        v.add("e");
        v.add("f");
        System.out.println("capacity after adding 6elemnts "+v.capacity());//initial capacity is full
        v.add("g");
        System.out.println("capacity after adding 7th element"+v.capacity());//increaments capacity by 3
        Enumeration<String> s=v.elements();
        while(s.hasMoreElements())//to read & print each value of the vector
        {
            System.out.println("hello "+s.nextElement());
        }
    }
}