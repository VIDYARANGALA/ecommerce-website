//to demostrate hashtable and its methods
import java.util.*;
class hashmap
{
    public static void main(String asd[])
    {
        HashMap<String,String> map=new HashMap<String,String>();

        System.out.println("is hashmap empty? "+map.isEmpty());//isempty

        map.put("vidya","rangala");//put() to add data into hashmap
        map.put("jayesh","vallimali");
        map.put("virat","kohli");
        map.put("mahendra singh","dhoni");
        System.out.println("size of hashmap is: "+map.size());//to know the size
        System.out.println("keyset"+map.keySet());//returns all the keys
        System.out.println("values"+map.values());//returns all the values
        System.out.println("get "+map.get("vidya"));//returns value of give key
        System.out.println("get "+map.get("rangala"));//cannot get data of key if we specific value
        System.out.println("entryset"+map.entrySet());//returns all the keys and values
        System.out.println("contains key "+map.containsKey("jayesh"));//to check whether a key is there
        System.out.println("contains value "+map.containsValue("kohli"));//to check whether a value is there
        System.out.println("is hashmap empty now? "+map.isEmpty());
    }
}