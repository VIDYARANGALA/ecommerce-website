//to demostrate array of objects
class Student
{
    String name;
    int age;
    Student(String n,int a)
    {
        name=n;
        age=a;
    }
}
class arrayofobjects
{
    public static void main(String arg[])
    {
        Student s1=new Student("vidya", 20);
        Student s2=new Student("mahi", 19);
        Student s3=new Student("manish", 19);
        Student s4=new Student("dev", 22);
        Student s5=new Student("VR", 19);

        Student students[]=new Student[5];
        students[0]=s1;
        students[1]=s2;
        students[2]=s3;
        students[3]=s4;
        students[4]=s5;
        for(int i=0;i<students.length;i++)
        {
            Student s=students[i];
            System.out.println(s.name);
            System.out.println(s.age);
        }

    }
}