//to demostrate gridbaglayout
import java.awt.*;
class gridbag extends Frame
{
    public static void main(String args[])
    {
        gridbag f=new gridbag();
        f.setSize(100,200);
        f.setVisible(true);

        GridBagLayout g1=new GridBagLayout();
        GridBagConstraints cons=new GridBagConstraints();
        f.setLayout(g1);

        cons.gridx=(0);
        cons.gridy=(0);
        Button b1=new Button("enter");
        g1.setConstraints(b1, cons);
        f.add(b1);

        cons.gridx=(2);
        cons.gridy=(3);
        cons.weightx=0.40;//to get space between elements horizontally
        cons.weighty=1.20;//to get space between elements vertically
        Button b2=new Button("exit");
        g1.setConstraints(b2,cons);
        f.add(b2);

        cons.gridx=(1);
        cons.gridy=(0);
        Button b3=new Button("login");
        g1.setConstraints(b3,cons);
        f.add(b3);

        cons.gridx=(1);
        cons.gridy=(1);
        Button b4=new Button("register");
        g1.setConstraints(b4,cons);
        f.add(b4);

    }
}