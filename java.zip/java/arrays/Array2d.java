class Array2d
{
	public static void main(String arg[])
	{
		int marks[][]={{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}};
		for(int i=0;i<3;i++)//loop for accesing row index
		{
			for(int j=0;j<5;j++)//loop for accessing col index
			{
				System.out.print(marks[i][j]+"\t");
			}
			System.out.println();
		}
	}
}
