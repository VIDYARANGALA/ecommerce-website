class Array3d
{
	public static void main(String a[])
	{
		int clgmarks[][][]={
					{{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}},
					{{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}},		
					{{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}}
				    };
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				for(int k=0;k<5;k++)
				{
					System.out.print(clgmarks[i][j][k]+"\t");
				}
			}

			System.out.println("\t");

		}
		
		System.out.println();
	}
}					

