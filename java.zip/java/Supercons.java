// to call super constructor in sub class using super keyword
class A
{
    int a;
    int b;
    int c;
    A(){}
    A(int a,int b,int c)
    {
        this.a=a;
        this.b=b;
        this.c=c;
    }
}
class B extends A
{
    int d;
    int e;
    B(){}
    B(int a,int b,int c,int d,int e)
    {
        super(a,b,c);//calling super class constructor
        this.d=d;
        this.e=e;
       
    }
    void add()
        {
            System.out.println(a+b+c+d+e);
        }
    
}
class Supercons
{
    public static void main(String a[])
    {
        B obj=new B(10,20,30,40,50);
        obj.add();
    }
}