//constructor
class A 
{
    String name;
    A()//default constructor
    {
        name="java programming";
    }
   
    A(String name)//parametrized constructor
    {
        this.name=name;
    }
}
class This
{
    public static void main(String a[])
    {
        A object=new A();
        System.out.println(object.name);

        A obj1=new A("rgukt");
        System.out.println(obj1.name);
    }
}