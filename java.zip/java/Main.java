import Package.*;
class Main
{
    public static void main(String a[])
    {
        first obj=new first();
        System.out.println(obj.x);
        System.out.println(obj.y);
        obj.add();
        Second obj1=new Second();
        obj1.sub();
      
    }
}