//inheritance
class A {
    int p;

    A() {
    }

    A(int a) {
        p = a;
    }

    void display() {
        System.out.print("value of base class is" + p);
    }
}

class B extends A {
    int q;

    // B(){}
    B(int p, int q) {
        this.p = p;
        this.q = q;
    }

    void show() {
        System.out.println("value of derived clas is" + q);
    }

}

class Inheritance1 {
    public static void main(String a[]) {
        B obj = new B(23, 67);

        obj.display();

        obj.show();
    }
}
