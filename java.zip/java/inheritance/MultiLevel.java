//multilevel inheritance-subclass is derived from another subclass
class A
{
    int p;
    A(){}
    A(int p)
    {
        this.p=p;
    }
    void diss()
    {

    }
}
class B extends A
{
    int q;
    B(){}
    B(int p,int q)
    {
        this.p=p;
        this.q=q;
    }
    void show()
    {

    }
}
class C extends B
{
    int r;
    C(){}
    C(int p,int q,int r)
    {
        this.p=p;
        this.q=q;
        this.r=r;
    }
    void add()
    {
        System.out.println("addition is: "+(p+q+r));

    }
}
class MultiLevel
{
    public static void main(String f[])
    {
        C obj=new C(23,45,67);
        obj.add();
    }
}
