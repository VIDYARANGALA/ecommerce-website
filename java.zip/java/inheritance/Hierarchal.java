//hierarchal inheritance- multiple subclass derived from one super class
class A
{
    int p;
    A(){}
    A(int p)
    {
        this.p=p;
    }
    void nul()
    {

    }
}
class B extends A
{
    int q;
    B(){}
    B(int p,int q)
    {
        this.p=p;
        this.q=q;
    }
    void add()
    {
        System.out.println("addition of p,q is;: "+(p+q));
    }
}
class C extends A
{
    int r;
    C(){}
    C(int p,int r)
    {
        this.p=p;
       
        this.r=r;
    }
    void addition()
    {
        System.out.println("addion of p,r is: "+(p+r));
    }
}
class Hierarchal
{
    public static void main(String p[])
    {
        B obj1=new B(12,34);
        obj1.add();
        C obj2=new C(23,45);
        obj2.addition();
    }
}