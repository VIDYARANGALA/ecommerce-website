class A
{
    void method1()
    {
        System.out.println("method show in class A");

    }
}
interface B
{
    int a=10;
    void method2();
}
interface C
{
    void method3();
}
class D extends A implements B,C
{
    public void method2()
    {
        System.out.println("method2 in class D");

    }
    public void method3()
    {
        System.out.println("method3 in class D");
    }
}
class Multiple
{
    public static void main(String a[])
    {
        D obj=new D();
        obj.method1();
        obj.method2();
        obj.method3();
        System.out.println(B.a);

    }
}