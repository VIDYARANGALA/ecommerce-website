//accessing methods and variables from samepackage sub class
package accessmodifier;
public class spsc extends sameclass
{
    public spsc()
    {
        System.out.println("a value frow spsc"+a);
        //System.out.println("b value frow spsc"+b);
        System.out.println("c value frow spsc"+c);
        System.out.println("d value frow spsc"+d);
        
    }

}