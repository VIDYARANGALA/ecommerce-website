//creating a method using final keyword it doest support ovveriding
class A 
{
    int a=10;
    int b=23;
    final void add()
    {
        System.out.println("addition is "+(a+b));
    }
}
class B extends A
{
    int d=23;
    int s=34;
    void add()//error
    {
        System.out.println("addition is "+(a+b));
        System.out.println(d+s);
    }
}


class finalmethod
{
    public static void main(String ar[])
    {
       B obj=new B();
       obj.add();
    }
}