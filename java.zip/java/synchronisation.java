//to demonstrate sychronisation in threads
class ticketbooking
{
    boolean booked=false;
    public void ticketbooked(String name)
    {
        synchronized(this)
        {
            if(booked==false)
            {
                System.out.println(name+" selected seat");
                try {
                    Thread.sleep(1000);
                } catch (Exception e) {}
                
                System.out.println(name+" done payment");
                System.out.println(name+" got seat");
                booked=true;
            }
            else{
                System.out.println("sorry"+name+" seat is already booked");
            }
        }
    }
}
class threadclass extends Thread
{
    ticketbooking tkt;
    String name;
    threadclass(ticketbooking obj,String s)
    {
        tkt=obj;
        name=s;

    }
    public void run()
    {
        tkt.ticketbooked(name);
    }
}
class synchronisation 
{
    public static void main(String[] args) 
    {
        ticketbooking tb=new ticketbooking();
        threadclass san=new threadclass(tb,"santhosh");
        Thread santhosh=new Thread(san);
        santhosh.start();

        threadclass sur=new threadclass(tb,"suresh");
        Thread suresh=new Thread(sur);
        suresh.start();
        
        
    }
}