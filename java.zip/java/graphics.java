//to demonstrate graphics
import java.awt.*;
class graphics extends Frame
{
    public void paint(Graphics g)
    {
        g.setColor(Color.BLUE);
        g.drawLine(20,40 ,100 ,120 );
        //g.drawRect(120,300, 200,400);
        g.drawOval(20,30,200,200);
        g.drawOval(20,30,100,200);
        g.setColor(Color.CYAN);
        g.fillOval(120,300,200,400);
        g.setFont(new Font("Arial", Font.BOLD,40));
        g.drawString("vidyarangala",489 ,610);
    
    }
    public static void main(String args[])
    {
        graphics g=new graphics();
        g.setSize(400, 500);
        g.setVisible(true);
    }
}