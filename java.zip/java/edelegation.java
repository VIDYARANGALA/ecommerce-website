//to demonstrate event delegation model
import java.awt.*;
import java.awt.event.*;
class edelegation 
{
    public static void main(String args[])
    {
        Frame f=new Frame("title");//step1:creating a component
        f.setSize(400,600);
        f.setVisible(true);
        f.addWindowListener(new mylistener());//step3 implementin obj to the listener cls
        
    }
}
class mylistener implements WindowListener//step2 adding lister to the component
{
    public void windowClosing(WindowEvent e)
    {
        
        System.out.println("closing");
    }
    public void windowClosed(WindowEvent e)
    {
        System.exit(0);//to close the window using cross mark in window
        System.out.println("closed");
    }
    public void windowOpening(WindowEvent e)
    {
        System.out.println("opening");
    }
    public void windowActivated(WindowEvent e)
    {
        System.out.println("activated");
    }
    public void windowDeactivated(WindowEvent e)
    {
        System.out.println("deactivated");
    }
    public void windowIconified(WindowEvent e)
    {
        System.out.println("iconified");
    }
    public void windowDeiconified(WindowEvent e)
    {
        System.out.println("deiconified");
    }
    public void windowOpened(WindowEvent e)
    {
        System.out.println("opened");
    }
    
}