class LogicalNot
{
	public static void main(String args[])
	{
		byte x=20;
		byte y=30;
		if(!(x<y))
		{
			System.out.println("x is not less than y");
		}
		else
		{
			System.out.println("x is less than y");
		}
	}
}
