class Unary
{
	public static void main(String ar[])
	{
		byte x=4;
		//unary minus
		System.out.println("Result of unary minus is :"+(-x));
		//unary increment(post)
		System.out.println("Result of unary increment is :"+(x++));
		System.out.println(x);
		//unary increment(pre)
		System.out.println("Result of unary increment is :"+(++x));
		System.out.println(x);
		//unary decrement(post)
		System.out.println("Result of unary decrement is :"+(x--));
		System.out.println(x);
		//unary decrement(pre)
		System.out.println("Result of unary increment is :"+(--x));
		System.out.println(x);
	}
}
		
		
