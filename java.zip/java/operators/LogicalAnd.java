class LogicalAnd
{
	public static void main(String args[])
	{
		byte x=10;
		byte y=20;
		byte z=5;
		if(x<y && x<z)
		{
			System.out.println("x is smaller than y and z");
		}
		else if(x<y && x>z)
		{
			System.out.println("x is smaller than y and greater than z");
		}
		else
		
		{
			System.out.println(x);
		}
	}
}
