class Bitwise
{
	public static void main(String args[])
	{
		byte x=10;
		byte y=25;
		System.out.println("result of & is: "+(x&y));
		System.out.println("result of | is: "+(x|y));
		System.out.println("result of ~ is: "+(~y));
		System.out.println("result of ^ is: "+(x^y));
		System.out.println("result of << is: "+(x<<2));
		System.out.println("result of is: "+(x>>2));
		System.out.println("result of >>> is: "+(x>>>2));
	}
}
		

