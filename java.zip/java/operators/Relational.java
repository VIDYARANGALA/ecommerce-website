class Relational
{
	public static void main(String x[])
	{
		byte a=20;
		byte b=40;
		System.out.println("Results of == is: "+(a==b));
		System.out.println("Results of > is: "+(a>b));
		System.out.println("Results of >= is: "+(a>=b));
		System.out.println("Results of < is: "+(a<b));
		System.out.println("Results of <= is: "+(a<=b));
		System.out.println("Results of <= is: "+(a!=b));
	}
}
