class Arithmetic
{
	public static void main(String args[])
	{
		int x=4;
		byte y=2;
		//arthmetic operations

		System.out.println("Results of addition is: "+(x+y));
		System.out.println("Results of subtraction is: "+(x-y));
		System.out.println("Results of multiplication is: "+(x*y));
		System.out.println("Results of division is: "+(x/y));
		System.out.println("Results of modulus is: "+(x%y));
	}
}
