class Ternary
{
	public static void main(String args[])
	{
		byte x=5;
		byte y=3;
		System.out.println((x>y)?"x is greater":"y is greater");//if conditon true prints the statement which is after'?' if condition false prints statement which is after':'
	}
}
