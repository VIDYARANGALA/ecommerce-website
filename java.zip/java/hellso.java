class hellso
{
    public static void main(String args[])
    {
        System.out.println("helloworld");
    }
}