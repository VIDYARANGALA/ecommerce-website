//todemonstrate borderlayout
import java.awt.*;

import javax.swing.border.Border;
class borderlayout extends Frame
{
    public static void main(String arg[])
    {
        borderlayout b=new borderlayout();
        b.setSize(200,300);
        b.setVisible(true);
        BorderLayout bl=new BorderLayout(20,30);
        b.setLayout(bl);

        Button b1=new Button("enter");
        b.add(b1,BorderLayout.NORTH);
        Button b2=new Button("exit");
        b.add(b2,BorderLayout.SOUTH);
        Button b3=new Button("login");
        b.add(b3,BorderLayout.EAST);
        Button b4=new Button("signup");
        b.add(b4,BorderLayout.WEST);
        Button b5=new Button("register");
        b.add(b5,BorderLayout.CENTER);
        Button b6=new Button("goback");
        b.add(b6,BorderLayout.CENTER);
    }
}