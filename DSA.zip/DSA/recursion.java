public class recursion {

    // to print sum of first N natural numbers
    public static int natural(int n) {
        if (n == 1) {
            return 1;
        }

        int sn = n + natural(n - 1);
        return sn;
    }

    // print n natural numbers

    public static void nat(int n) {
        if (n == 0) {
            return;

        }
        nat(n - 1);
        System.out.println(n);
    }

    // print nth fibonacci number
    public static int fib(int n) {
        if (n == 0 || n == 1) {
            return n;
        }
        int fnm1 = fib(n - 1);
        int fnm2 = fib(n - 2);
        int fibn = fnm1 + fnm2;
        return fibn;
    }

    // check whether array is sorted or not
    public static boolean issorted(int array[], int i) {
        if (i == array.length - 1) {
            return true;
        }
        if (array[i] > array[i + 1]) {
            return false;
        }
        return issorted(array, i + 1);
    }

    // to print index of first occurence of a number
    public static int firstoccur(int array[], int key, int i) {

        if (i == array.length) {
            return -1;
        }
        if (array[i] == key) {
            return i;
        }
        return firstoccur(array, key, i + 1);

    }

    // //to print index of last occurence of a number
    public static int lastoccur(int array[], int key, int i) {
        if (i == array.length) {
            return -1;
        }
        int isfound = lastoccur(array, key, i + 1);
        if (isfound == -1 && array[i] == key) {
            return i;
        }
        return isfound;
    }

    // to print x to the power n
    public static int power(int x, int n) {
        if (n == 0) {
            return 1;
        }
        return x * power(x, n - 1);
    }

    // to print x to the power n(OPTIMIZED)

    public static int optpow(int x, int n) {
        if (n == 0) {
            return 1;
        }
        int power = optpow(x, n / 2) * optpow(x, n / 2);// if power is even
        if (n % 2 != 0) {
            power = x * power; // if power is odd
        }
        return power;

    }

    // TILING PROBLEM
    public static int tailing(int n) {
        if (n == 0 || n == 1) {// base condition
            return 1;
        }
        // vertical
        int fnm1 = tailing(n - 1);
        int fnm2 = tailing(n - 2);
        int totWays = fnm1 + fnm2;
        return totWays;
    }

    // remove duplicates from string
    public static void remDup(String str, int idx, StringBuilder newstr, boolean map[]) {
        if (idx == str.length()) {
            System.out.println(newstr);
            return;
        }
        char curr = str.charAt(idx);
        if (map[curr - 'a'] == true) {
            remDup(str, idx + 1, newstr, map);
        } else {
            map[curr - 'a'] = true;
            remDup(str, idx + 1, newstr.append(curr), map);
        }

    }

    public static void main(String[] args) {
        // int n = 5;
        // int array[]={1,2,3,6,3,7,5,6};

        // System.out.println(natural(n));//sum of n natural numbers

        // nat(5);//n natural numbers

        // System.out.println(fib(20));//fibonocci
        // System.out.println(issorted(array, 1)); //sorted array or not
        // System.out.println(firstoccur(array,6,0));//firstoccurence
        // System.out.println(lastoccur(array,6,0));//lastoccurence
        // System.out.println(power(2, 0));//power of xn
        // System.out.println(optpow(2, 7));//power of xn optimized
        // System.out.println(tailing(3));//tailing problem
        // String str="aappnacollege";

        // remDup(str, 0, new StringBuilder(""),new boolean[26]);//remove duplicates

    }
}