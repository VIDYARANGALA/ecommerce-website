
import java.util.LinkedList;

public class javaCollectionsFramework {
    public static void main(String ard[]){
        //creating a LinkedList using JCF
        //step1 create 
        LinkedList<Integer> ll=new LinkedList<>();
        //add elements
        ll.addFirst(1);
        ll.addFirst(2);
        ll.addFirst(3);
        ll.add(3, 4);//at index 3 add value 4
        ll.addLast(5);
        System.out.println(ll);
        //remove elemnts
        ll.removeFirst();
        ll.removeLast();
        ll.remove(2);//passing index 
        System.out.println(ll);
    }
}
