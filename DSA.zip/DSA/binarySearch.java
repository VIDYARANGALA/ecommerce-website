public class binarySearch {
    public static int search(int nums[], int key) {
        int start = 0;
        int end = nums.length - 1;
        while (start <= end) {
            int mid = (start + end) / 2;
            if (nums[mid] == key) {
                return mid;
            } else if (nums[mid] > key) {
                end = mid - 1;
            } else {
                start = mid + 1;
            }
        }
        return -1;
    }

    public static void main(String asd[]) {
        int nums[] = { 2, 4, 6, 8, 10, 12, 14 };
        int key = 14;
        System.out.println("key found at index " + search(nums, key));
    }
}
