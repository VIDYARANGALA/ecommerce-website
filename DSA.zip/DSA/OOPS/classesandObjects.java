public class classesandObjects {

    public static void main(String asd[]) {
        Pen p1 = new Pen();
        p1.setColor("blue");
        System.out.println(p1.color);
        p1.color = "lavender";
        System.out.println(p1.color);
    }
}

class Pen {
    int tip;
    String color;

    void setColor(String newColor) {
        color = newColor;
    }

    void setTip(int newTip) {
        tip = newTip;
    }
}
