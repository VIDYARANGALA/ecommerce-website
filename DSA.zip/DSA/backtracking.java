public class backtracking {
    // backtracking on arrays
    public static void changearr(int arr[], int i, int val) {
        if (i == arr.length) {
            printarr(arr);
            return;
        }
        arr[i] = val;
        changearr(arr, i + 1, val + 1);
        arr[i] = arr[i] - 2;
    }

    public static void printarr(int arr[]) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    // finding subsets
    public static void findSubSet(String str, String ans, int i) {
        // base condition

        if (i == str.length()) {
            if (ans.length() == 0) {
                System.out.println("null");
            }
            System.out.println(ans);
            return;
        }

        // for YES choice
        findSubSet(str, ans + str.charAt(i), i + 1);
        // for NO choice
        findSubSet(str, ans, i + 1);
    }

    // permutatons
    public static void permutation(String str, String ans) {
        if (str.length() == 0) {
            System.out.println(ans);
            return;
        }
        for (int i = 0; i < str.length(); i++) {
            char curr = str.charAt(i);
            // "abcd"-> ab+d=abd below line remove char at ith index and prints rest
            String newStr = (str.substring(0, i) + str.substring(i + 1));
            permutation(newStr, ans + curr);
        }
    }

    public static void main(String ars[]) {
        // int arr[] = new int[5];
        // changearr(arr, 0, 1); //backtracking on arrays
        // printarr(arr); //backtracking on arrays
        String str = "abc";
        // findSubSet(str, "", 0);//subset
        permutation(str, "");// permutation

    }

}