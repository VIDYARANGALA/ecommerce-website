import java.util.*;

public class deque {
    public static void main(String ad[]) {
        Deque<Integer> d = new LinkedList<>();
        d.addFirst(1);
        d.addFirst(2);
        d.addLast(3);
        d.addLast(4);
        System.out.println(d);
        // d.removeLast();
        // System.out.println(d);
        System.out.println("first element is " + d.getFirst());
        System.out.println("last element is " + d.getLast());
    }
}
