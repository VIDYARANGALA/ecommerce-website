public class linearSearch {
    static int i;

    public static int search(int nums[], int key) {
        for (i = 0; i < nums.length; i++) {
            if (nums[i] == key) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String ar[]) {
        int nums[] = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };
        int key = 20;
        int index = search(nums, key);
        if (index == -1) {
            System.out.println("key not found ");
        } else {
            System.out.println("key found at index " + i);
        }
    }
}
