public class leafNodeSum {
    static class Node {
        int data;
        Node right;
        Node left;

        Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    public static int leafSum(Node root) {
        if (root == null) {
            return 0;

        }
        if (root.left == null && root.right == null) {
            return root.data;
        }

        int rightSum = leafSum(root.right);
        int leftSum = leafSum(root.left);
        return rightSum + leftSum;
    }

    public static void main(String ad[]) {
        Node root = new Node(1);
        root.left = new Node(2);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.right = new Node(3);
        root.right.right = new Node(6);
        System.out.println("sum of leaf nodes is: " + leafSum(root));

    }
}
