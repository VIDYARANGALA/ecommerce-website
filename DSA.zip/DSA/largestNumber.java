public class largestNumber {
    public static int largest(int nums[]) {
        int largestnum = Integer.MIN_VALUE;
        for (int i = 0; i < nums.length; i++) {
            if (largestnum < nums[i]) {
                largestnum = nums[i];
            }
        }
        return largestnum;
    }

    public static void main(String asj[]) {
        int nums[] = { 1, 2, 5, 4, 8, 67, 44 };
        System.out.println("largest number is " + largest(nums));

    }
}
