public class mergesort{
    public static void printarr(int array[]) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static void mergeSort(int array[], int si, int ei) {
        if (si >= ei) {// base case
            return;
        }
        int mid = si + (ei - si) / 2;// get mid
        mergeSort(array, si, mid);// sorting left part
        mergeSort(array, mid + 1, ei);// sorting right part
        merge(array, si, mid, ei);

    }

    public static void merge(int array[], int si, int mid, int ei) {
        int temp[] = new int[ei - si + 1];
        int i = si;// iterator for left part
        int j = mid + 1;// iterator for right part
        int k = 0;// iterator for temp
        while (i <= mid && j <= ei) {
            if (array[i] < array[j]) {
                temp[k] = array[i];
                i++;
            } else {
                temp[k] = array[j];
                j++;

            }
            k++;
        }
        // leftover left part
        while (i <= mid) {
            temp[k++] = array[i++];
        }
        // leftover right part
        while (j <= ei) {
            temp[k++] = array[j++];
        }
        // copy temp to original array
        for (k = 0, i = si; k < temp.length; k++, i++) {
            array[i] = temp[k];
        }

    }

    public static void main(String args[]) {
        int array[] = { 6, 3, 9, 5, 2, 8 };
        mergeSort(array, 0, array.length - 1);
        printarr(array);

    }
}
