import java.util.ArrayList;

public class validBST {
    static class Node {
        int data;
        Node left;
        Node right;

        Node(int data) {
            this.data = data;
        }
    }

    public static Node insert(Node root, int val) {
        if (root == null) {
            return root = new Node(val);
        }

        if (root.data > val) {
            root.left = insert(root.left, val);
        } else {
            root.right = insert(root.right, val);
        }
        return root;
    }

    public static boolean isValid(Node root, Node min, Node max) {
        if (root == null) {
            return true;
        }
        // right subtree
        if (min != null && root.data <= min.data) {
            return false;
        }
        // leftsubtree
        else if (max != null && root.data >= max.data) {
            return false;
        }

        return isValid(root.left, min, root)
                && isValid(root.right, root, max);
    }

    public static void main(String[] args) {
        int values[] = { 1, 2, 1 };
        // int values[] ={8, 5, 3, 1, 4, 6, 10, 11, 14};
        Node root = null;
        for (int i = 0; i < values.length; i++) {
            root = insert(root, values[i]);
        }

        if (isValid(root, null, null)) {
            System.out.println("valid BST");
        } else {
            System.out.println("invalid BST");
        }

    }
}
