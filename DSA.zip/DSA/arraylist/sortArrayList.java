import java.util.*;

public class sortArrayList {

    public static void main(String ar[]) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(8);
        list.add(2);
        list.add(11);
        list.add(5);
        list.add(3);
        System.out.println("before sorting" + list);
        Collections.sort(list);// asceding order sort
        System.out.println("after sorting" + list);
        // descending order sort
        Collections.sort(list, Collections.reverseOrder());
        System.out.println("after descending sort" + list);

    }

}