import java.util.*;

public class arrayList {
    public static void main(String ards[]) {
        // syntax
        ArrayList<Integer> list = new ArrayList<>();
        list.add(8);// addding a elements into list 0(1)
        list.add(2);
        list.add(11);
        list.add(5);
        list.add(3);
        list.add(3, 9);// adds 9 at index 3
        System.out.println(list);
        // to get element 0(1)
        // System.out.println(list.get(2));
        // to remove an element
        // System.out.println(list.remove(1) + " is removed");
        // System.out.println(list);
        // to set(replace) a element at a index
        // list.set(1, 10);// at index 1 set 10
        // System.out.println(list);
        // to check an element exist or not
        System.out.println(list.contains(1));
        System.out.println(list.contains(11));
        // to know size of array list
        // System.out.println(list.size());
        // to print arraylist
        // for (int i = 0; i < list.size(); i++) {
        // System.out.print(i);// 1st way
        // System.out.print(list.get(i));// 2nd way

        // }
        // System.out.println();

        // print reverse
        // for (int i = list.size() - 1; i >= 0; i--) {
        // System.out.print(list.get(i) + " ");
        // }
        // System.out.println(" reversed");

        // max in an arraylist
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < list.size(); i++) {
            // if (max < list.get(i)) {
            // max = list.get(i);
            // }
            // another way to find max
            max = Math.max(max, list.get(i));
        }

        System.out.println("max element is " + max);

    }
}
