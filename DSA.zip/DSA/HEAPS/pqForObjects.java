import java.util.*;

public class pqForObjects {
    static class Students implements Comparable<Students> {
        String name;
        int rank;

        public Students(String name, int rank) {
            this.name = name;
            this.rank = rank;
        }

        @Override
        public int compareTo(Students s2) {
            return this.rank - s2.rank;
        }
    }

    public static void main(String aj[]) {
        PriorityQueue<Students> pq = new PriorityQueue<>();// (Comparator.reverseOrder());
        pq.add(new Students("A", 4));
        pq.add(new Students("B", 5));
        pq.add(new Students("C", 2));
        pq.add(new Students("D", 12));

        while (!pq.isEmpty()) {
            System.out.println(pq.peek().name + "->" + pq.peek().rank);
            pq.remove();
        }
    }
}
