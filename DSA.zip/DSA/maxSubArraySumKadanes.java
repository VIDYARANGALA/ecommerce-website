public class maxSubArraySumKadanes {
    public static void kadanes(int nums[]) {
        int currSum = 0;
        int maxSum = Integer.MIN_VALUE;
        for (int i = 0; i < nums.length; i++) {
            currSum = currSum + nums[i];
            maxSum = Math.max(maxSum, currSum);
            if (currSum < 0) {
                currSum = 0;
            }
            System.out.println(currSum);

        }
        System.out.println("max subarray sum is " + maxSum);
    }

    public static void main(String as[]) {
        int nums[] = { 2, 4, 6, 8, 10 };
        kadanes(nums);
    }
}