public class powerOf2OrNot {
    public static boolean root(int n) {
        return (n & (n - 1)) == 0;
    }

    public static void main(String sd[]) {
        System.out.println(root(12));
        System.out.println(root(8));
        System.out.println(root(20));
        System.out.println(root(232));
        System.out.println(root(23));

    }
}
