public class evenOrOdd {
    public static void oddOrEven(int n) {
        int bitmask = 1;
        if ((n & bitmask) == 0) {
            System.out.println("even number");
        } else {
            System.out.println("odd number");
        }
    }

    public static void main(String at[]) {
        oddOrEven(2);
        oddOrEven(44);
    }
}
