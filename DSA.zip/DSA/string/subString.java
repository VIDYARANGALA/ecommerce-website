public class subString {
    public static String sub(String s, int si, int ei) {
        String str = "";
        for (int i = si; i < ei; i++) {
            str += s.charAt(i);
        }
        return str;
    }

    /*
     * public static void main(String sd[]) {
     * String s = "Hello World";
     * System.out.println(sub(s, 0, 7));
     * }
     * }
     */
    // using inbuilt function
    public static void main(String ags[]) {
        String s = "Hello World";
        System.out.println(s.substring(1, 7));
    }
}
