public class largestString2 {
    public static void main(String sd[]) {
        String names[] = { "vidya", "rangala", "vallimalai", "vjr" };
        String largest = "";
        int maxLength = 0;
        for (int i = 0; i < names.length; i++) {
            String str = names[i];
            int currlength = str.length();
            if (currlength > maxLength) {
                maxLength = currlength;
                largest = str;
            }

        }
        System.out.println(largest);
    }
}
