public class largestString {
    public static void main(String sdy[]) {
        String s[] = { "vidya", "rangala", "vallimalai", "vjr" };
        String largest = s[0];
        for (int i = 1; i < s.length; i++) {
            if (largest.compareTo(s[i]) < 0) {
                largest = s[i];
            }
        }
        System.out.println(largest);
    }
}
