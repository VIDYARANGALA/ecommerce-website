public class fibonacci {
    public static void main(String as[]) {
        int n = 10;
        for (int i = 0; i <= n; i++) {
            System.out.println(fibonnaci(i) + "");
        }

    }

    public static int fibonnaci(int n) {
        if (n < 2) {
            return n;
        }

        return fibonnaci(n - 1) + fibonnaci(n - 2);
    }
}
