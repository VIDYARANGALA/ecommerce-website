public class lowestCommon Ancestor1 {
    
}
