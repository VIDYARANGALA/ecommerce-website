import java.util.*;

class iterationOnHashSet {

    public static void main(String as[]) {
        HashSet<String> cities = new HashSet<>();
        cities.add("Delhi");
        cities.add("Mumbai");
        cities.add("Noida");
        cities.add("Benguluru");

        // iteration using iterator
        /*
         * Iterator it = cities.iterator();
         * while (it.hasNext()) {
         * System.out.println(it.next());
         * }
         */

        // iteration using advanced for loops
        for (String city : cities) {
            System.out.println(city);
        }
    }
}
