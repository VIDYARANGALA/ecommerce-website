import java.util.*;

public class uniquesNumbersSum {

    public static void main(String ars[]) {
        int nums[] = { 1, 2, 2, 3, 4, 5, 3 };
        HashSet<Integer> set = new HashSet<>();
        int sum = 0;
        for (int i = 0; i < nums.length; i++) {
            if (!set.contains(nums[i])) {
                set.add(nums[i]);
                 sum += nums[i];
            } else if (set.contains(nums[i])) {
                set.remove(nums[i]);
                sum-=nums[i];
                
            }
            
        }
        System.out.println(set);
        System.out.println(sum);
    }
}