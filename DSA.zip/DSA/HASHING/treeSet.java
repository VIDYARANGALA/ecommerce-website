import java.util.*;

public class treeSet {
    public static void main(String as[]) {
        TreeSet<String> ts = new TreeSet<>();
        ts.add("Delhi");
        ts.add("Mumbai");
        ts.add("Noida");
        ts.add("Benguluru");
        System.out.println(ts);

    }
}
