<?php

// Database constants
define("HOST", "localhost");
define("USER", "root");
define("PW", "neoben");
define("DB", "ecommerce");

// Session Class constants
define("SESSIONS", "sessions");
define("SESSIONID", "sid");
define("SESSIONDATA", "sdata");
define("SESSIONEXPIRE", "sexpire");

?>
